package br.com.fiap.spring_mvc.repository;

public interface LivroRepository {

}
