import { Text, View } from 'react-native';
import { styles } from './App';


export default function App() {
    return (
        <View style={styles.container}>
      const numero1 = () => { }
            return <View>
                <Text>Insira um número</Text>
                <TextInput
                    style={{
                        height: 40,
                        borderColor: 'gray',
                        borderWidth: 1,
                    }}
                    defaultValue="Número" />
            </View>
      }

  
      const numero2 = () => { }
            return <View>
                <Text>Insira um número</Text>
                <TextInput
                    style={{
                        height: 40,
                        borderColor: 'gray',
                        borderWidth: 1,
                    }}
                    defaultValue="Número" />
            </View>
      }

      const numero3 = () => { }
            return <View>
                <Text>Insira um número</Text>
                <TextInput
                    style={{
                        height: 40,
                        borderColor: 'gray',
                        borderWidth: 1,
                    }}
                    defaultValue="Número" />
            </View>
      }

      getMaiorNumero = (numero1, numero2, numero3) => { }
            return <View>
                let viewA = null
                if ({numero1 >= numero2 && numero1 >= numero3}) {viewA = (<View><Text>O maior número é ${numero1}</Text></View>)}
                if ({numero2 >= numero1 && numero2 >= numero3}) {viewA = (<View><Text>O maior número é ${numero2}</Text></View>)}
                if ({numero3 >= numero2 && numero3 >= numero1}) {viewA = (<View><Text>O maior número é ${numero3}</Text></View>)}
            </View>
        </View>
    );
}
