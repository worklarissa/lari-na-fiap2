import { useState } from 'react';
import { Button, Image, StyleSheet, TextInput, View } from 'react-native';
import ReceberDados from './components/ReceberDados';



export default function App() {
  const [nomeMiranha, setNomeMiranha] = useState('')
  const [nomeDimensao, setNomeDimensao] = useState('')
  const [nomeEvento, setNomeEvento] = useState('')

  function meusDados(name) {
    console.log(name)
  }

  return (
    <View style={styles.container}>
      <View>
        <Image
          source={require("./assets/download.png")}
          style={styles.image}
        />
      </View>
      <View>
        <TextInput
          style={styles.input}
          placeholder='Qual miranha você é?'
          keyboardType='default'
          value={nomeMiranha}
          onChangeText={(text) => setNomeMiranha(text)}
        />
        <TextInput
          style={styles.input}
          placeholder='De qual dimensão você é?'
          keyboardType='default'
          value={nomeDimensao}
          onChangeText={(text) => setNomeDimensao(text)}
        />
        <TextInput
          style={styles.input}
          placeholder='Qual evento canônico você passou?'
          keyboardType='default'
          value={nomeEvento}
          onChangeText={(text) => setNomeEvento(text)}
        />
      </View>

      <Button
        style={{ marginTop: 50, borderRadius: 10 }}
        title='Enviar'
        onPress={() => { <ReceberDados nameMiranha={nomeMiranha} /> }} />

      <ReceberDados nameMiranha={nomeMiranha} />

    </View>



  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
  },
  image: {
    resizeMode: 'center',
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 10,
    width: 370,
    marginTop: 20

  }
});
