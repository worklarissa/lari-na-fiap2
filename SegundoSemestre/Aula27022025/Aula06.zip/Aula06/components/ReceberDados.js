import { Text } from "react-native";
 
 
export default ({nameAluno}) =>{
    return(
        <Text style={{color:"#fff"}}>{nameAluno}</Text>
    )
}