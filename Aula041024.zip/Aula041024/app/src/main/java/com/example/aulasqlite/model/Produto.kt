package com.example.aulasqlite.model

data class Produto(
    val idProduto:Int,
    val titulo:String,
    val descricao:String
)
