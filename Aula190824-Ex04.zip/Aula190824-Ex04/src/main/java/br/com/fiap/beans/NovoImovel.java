package br.com.fiap.beans;

import br.com.fiap.beans.Imovel;

public     class NovoImovel extends Imovel{
    public double AdicionalPreco(){
        this.setPreco(getPreco() + 10000);

    }
}

