package br.com.fiap.beans;

public class VelhoImovel extends Imovel{
    private void VelhoPreco();

    public double AdicionalPreco(){
        this.VelhoPreco = this.setPreco(getPreco() - 200);
        System.out.println("O preço do novo método");
        return VelhoPreco;
    }
}

