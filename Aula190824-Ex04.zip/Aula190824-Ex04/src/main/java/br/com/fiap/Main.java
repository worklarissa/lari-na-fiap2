package br.com.fiap;

import br.com.fiap.beans.Imovel;
import br.com.fiap.beans.NovoImovel;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Imovel casa1 = new Imovel("Avenida Paulista, 1106", 200000);
        NovoImovel casa2 = new NovoImovel("Rua dos Pamplonas,2330", 400000)
        };

    }